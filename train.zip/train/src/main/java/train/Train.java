package train;

import java.util.LinkedList;

import Factory.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> train
 * Package =====> train
 * Date    =====> 17 nov. 2019 
 */
public class Train {
	private String Test;
	private FactoryC factc = new FactoryC();
	private FactoryH facth = new FactoryH();
	private FactoryR factr  = new FactoryR();
	private FactoryP factp  = new FactoryP();
	private FactoryF factf  =  new FactoryF ();
	
	/**
	 * 
	 */
	public Train() {
		// TODO Auto-generated constructor stub
	}
	
	public Train(String test) {
		this.Test = test;
	}
	
	public String print() {
		 StringBuilder sb  = new StringBuilder();
		
		String[]results = Test.split("");
		for(int i=0;i<results.length; i++) {
			//System.out.println(factp.getInstance());
			if(results[i].equals("P")) {sb.append(factp.getInstance()+"::");}
			if(results[i].equals("H") && i <results.length-1) {sb.append(facth.getInstance()+"::");}
			if(results[i].equals("H") && i ==results.length-1) {sb.append(facth.getInstance().getEnd()+"::");}
			if(results[i].equals("F")) {sb.append(factf.getInstance()+"::");}
			if(results[i].equals("R")) {sb.append(factr.getInstance()+"::");}
			if(results[i].equals("C")) {sb.append(factc.getInstance()+"::");}
			
		}
		sb.delete(sb.length()-2, sb.length());
		
		 return sb.toString();

	}
	
	public void detachEnd() {
        StringBuilder sb = new StringBuilder();
		String[]results = Test.split("");
        
        sb.append(Test);
        sb.delete(results.length-1, results.length);
        setTest(sb.toString());
	}
	
	public void detachHead() {
		   StringBuilder sb = new StringBuilder();
			String[]results = Test.split("");
	        
	        sb.append(Test);
	        sb.delete(0, 1);
		    setTest(sb.toString());
	}
	
	public boolean fill() {
		  boolean test=true;
		  StringBuilder sb = new StringBuilder();
			String[]results = Test.split("");
			int i;
	        for( i =0; i<results.length ;i++) {
	        	if(results[i].equals("C")) {
	        		sb.append("F");
	        		test = false;
	        		break;}
	        	sb.append(results[i]);  }
	        for(int j = i+1;j<results.length; j++) {
	        	sb.append(results[j]); }
	     setTest(sb.toString());
	     return test;
	}
	
	/**
	 * @param test the test to set
	 */
	public void setTest(String test) {
		Test = test;
	}
	
	

}
