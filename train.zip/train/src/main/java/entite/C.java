package entite;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> train
 * Package =====> entite
 * Date    =====> 17 nov. 2019 
 */
public class C {
	/**
	 * 
	 */
	public C() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "|____|";
	}

}
