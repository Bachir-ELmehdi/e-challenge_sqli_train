package entite;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> train
 * Package =====> entite
 * Date    =====> 17 nov. 2019 
 */
public class P {
	
	/**
	 * 
	 */
	public P() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "|OOOO|";
	}

}
