package entite;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> train
 * Package =====> entite
 * Date    =====> 17 nov. 2019 
 */
public class F {
	
	public F() {
		
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "|^^^^|";
	}

}
