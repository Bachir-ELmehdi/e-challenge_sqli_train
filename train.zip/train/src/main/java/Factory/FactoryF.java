package Factory;

import entite.F;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> train
 * Package =====> Factory
 * Date    =====> 17 nov. 2019 
 */
public class FactoryF {
	public F getInstance() {
		return new F();
	}

}
