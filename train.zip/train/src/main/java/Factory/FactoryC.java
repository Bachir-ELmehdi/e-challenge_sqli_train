package Factory;

import entite.C;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> train
 * Package =====> Factory
 * Date    =====> 17 nov. 2019 
 */
public class FactoryC {
	public C getInstance() {
		return new C();
	}

}
