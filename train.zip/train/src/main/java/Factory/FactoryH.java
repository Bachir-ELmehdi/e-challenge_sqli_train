package Factory;

import entite.H;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> train
 * Package =====> Factory
 * Date    =====> 17 nov. 2019 
 */
public class FactoryH {
	public H getInstance() {
		return new H();
	}

}
